# Django eCommerce website

Basic django eCommerce website with checkout guest checkout and paypal integration

Installation:

1. Clone repo: `git clone <repo_url>`
2. Install dependencies: `pip install -r requirements.txt`
3. Run server: `python manage.py runserver`

<img src="./static/images/demo.png"/>
